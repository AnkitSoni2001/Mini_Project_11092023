import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../../Style/SignUp/SignUp.css";
import Image from "../../Images/logo.png";
import SignUpApi from "../../Service/SignUp/SignUpApi";

const signUpApi = new SignUpApi();

const SignUp = () => {
    var Navigate = useNavigate();

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    // const [emailError, setEmailError] = useState(null);
    // const [passwordError, setPasswordError] = useState(null);

    const Info = {
        name: name,
        email: email,
        password: password,
    };

    const validateEmail = (email) => {
        const emailRegex = /^[a-zA-Z0-9._-]+@jmangroup\.com$/;
        return emailRegex.test(email);
    };

    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&!])[A-Za-z\d@#$%^&!]{8,}$/;
        return passwordRegex.test(password);
    };

    const handleBlurEmail = () => {
        if (email && !validateEmail(email)) {
            toast.error("Email should be of the format user@jmangroup.com");
        }
    };

    const handleBlurPassword = () => {
        if (password && !validatePassword(password)) {
            toast.error("Password should contain at least 8 characters with at least one uppercase letter, one lowercase letter, one numeric value, and one special character.");
        }
    };

    // const showError = (errorMessage) => {
    //     return errorMessage ? (
    //         <div className="error-message" style={{ color: "darkred" }}>{errorMessage}</div>
    //     ) : null;
    // };

    const handleSignUp = async () => {
        // setEmailError(null);
        // setPasswordError(null);

        if (name && email && password && confirmPassword) {
            if (password === confirmPassword) {
                const emailIsValid = validateEmail(email);
                const passwordIsValid = validatePassword(password);

                if (!emailIsValid) {
                    toast.error("Email should be of the format user@jmangroup.com");
                }

                if (!passwordIsValid) {
                    toast.error("Password should contain at least 8 characters with at least one uppercase letter, one lowercase letter, one numeric value, and one special character.");
                }

                if (emailIsValid && passwordIsValid) {
                    
                    await signUpApi.SignUp(Info, Navigate);
                }
            } else {
                alert("Password does not match!");
            }
        } else {
            alert("All fields are required!");
        }
    };

    return (
        <div className="signUpContainer">
            <div className="singnup_head">
                <img src={Image} className="logo" alt="Logo" />
                <h2 className="signup_h2">Jin</h2>
            </div>

            <form className="signUpForm">

                <div className="name">
                    <label className="lable">Name*</label>
                    <input className="input" type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </div>

                <div className="email">
                    <label className="lable">Email*</label>
                    <input
                        className="input"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        onBlur={handleBlurEmail} // Validate on blur
                    />
                    {/* {showError(emailError)} */}
                </div>

                <div className="password">
                    <label className="lable">Password*</label>
                    <input
                        className="input"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        onBlur={handleBlurPassword} // Validate on blur
                    />
                    {/* {showError(passwordError)} */}
                </div>

                <div className="password">
                    <label className="lable">Confirm Password*</label>
                    <input className="input" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                </div>

                <div>
                    <button type="button" className="signup_btn" onClick={handleSignUp}>
                        Sign Up
                    </button>
                </div>

                <div className="signup_footer">
                    <p className="signup_p_tag">
                        Already Registered! <a href="/">Sign In</a>
                    </p>
                </div>
            </form>
            <ToastContainer autoClose={5000} position="top-right" />
        </div>
    );
};

export default SignUp;
