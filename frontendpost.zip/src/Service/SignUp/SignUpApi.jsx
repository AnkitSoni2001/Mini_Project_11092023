import React from 'react'
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class SignUpApi{

    async SignUp(Info, Navigate) {
    
        const postRequest = await axios.post("http://localhost:8000/signup", Info);
        console.log(postRequest.data.message);
        if (postRequest.data.message === "User created") {
            // alert("You have successfully Signed Up!");
            toast.error("You have successfully Signed Up!", { autoClose: 2000 });
            Navigate("/");
        }
    
        if (postRequest.data.message === "User already exists") {
            // alert("User already exists");
            toast.error("User already exists", { autoClose: 2000 });
            Navigate("/");
        }
    }
}

export default SignUpApi