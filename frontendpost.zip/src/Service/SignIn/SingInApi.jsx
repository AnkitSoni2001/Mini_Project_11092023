import React from 'react'
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class SingInApi{
    async  SingIn(Info, Navigate) {
    
        const response = await axios.post("http://localhost:8000/signin", Info);
        const responseData = response.data;
    
        if (responseData.message === "Login Successfully") {
            // alert("You have successfully logged in!");
            toast.success("You have successfully logged in!", { autoClose: 2000 });
            Navigate("/home");
        }
    
        if (responseData.message === "Password Incorrect") {
            // alert("Invalid credentials");
            toast.error("Invalid credentials", { autoClose: 2000 });
        }
    
        if (responseData.message === "User does not exist") {
            // alert("User does not exist");
            toast.error("User does not exist", { autoClose: 2000 });
        }
    
        // if (responseData.message === "All fields are required") {
        //     alert("All fields are required");
        // }
    }
}

export default SingInApi
